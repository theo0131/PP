-- Ion Teodora-Andreea
-- Group: 324CB

{-
    PP Project 2021

    This is where you will write the implementation for the given tasks.
    You can add other modules aswell.
-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE FlexibleInstances #-}

module Tasks where

import Dataset
import Data.List
import Text.Printf
import Data.Array

type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]

{-
    TASK SET 1
-}

-- Task 1

-- Parses a matrix of strings to a matrix of floats
parseM :: [[String]] -> [[Float]]
parseM = map (map read)


-- Deletes the first line in matrix
-- and the first and last column
cut :: [[String]] -> [[String]]
cut m = map (\r -> (drop 1 $ 
        take ((length r)-1) r)) $ 
        drop 1 m


-- Calculates the points from the 6 questions
calculate :: [[String]] -> [Float]
calculate m = map ((/4).(foldr (\x y -> x + y) 0)) $ 
        (parseM.(map (map (\c -> if c == "" then "0" else c)))) $
        cut m


-- Adds the exam to the grade
addEx :: [[String]] -> [Float] -> [[Float]]
addEx m1 m2 = map (\c -> [c]) $
        zipWith (+) (map (read.(!! 7)) $
        drop 1 m1) m2


compute_exam_grades :: Table -> Table
compute_exam_grades m = ["Nume" , "Punctaj Exam"] :
        zipWith op (drop 1 m) (map (map (printf "%.2f")) $
        addEx m (calculate m))
    where 
        op r l = (head r) : l


-- Task 2

-- Number of students who have passed the exam:
get_passed_students_num :: Table -> Int
get_passed_students_num m = length $
        filter (>=2.5) $
        map (read.(!! 1)) (drop 1 $
        compute_exam_grades m)


-- Percentage of students who have passed the exam:
get_passed_students_percentage :: Table -> Float
get_passed_students_percentage m = a / b
    where 
        a = fromIntegral (get_passed_students_num m) :: Float
        b = fromIntegral (length m - 1) :: Float


-- Average exam grade
get_exam_avg :: Table -> Float
get_exam_avg m = (foldr (+) 0 a) / (fromIntegral (length a) :: Float)
    where 
        a = (map (read.(!! 1)) (drop 1 (compute_exam_grades m)))


-- Number of students who gained at least 1.5p from homework:
get_passed_hw_num :: Table -> Int
get_passed_hw_num m = length $
        filter (>=1.5) $
        map (foldr (+) 0) ((parseM.(map (map replace))) $ 
        extract m)
    where 
        extract m = map (\r -> (take 3 $ drop 2 r)) $ drop 1 m
        replace = \c -> if c == "" then "0" else c


-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs m = ["Q1", "Q2", "Q3", "Q4", "Q5", "Q6"] : 
        [map (printf "%.2f") $
        map (/a) $ 
        foldr op [] (parseM.(map $
        map (\c -> if c == "" then "0" else c)) $ 
        cut m)]
    where 
        op x [] = x
        op x y = zipWith (+) x y
        a = fromIntegral (length m - 1) :: Float


-- Task 4

--Parses a matrix of strings to a matrix of integers
parseMInt :: [[String]] -> [[Int]]
parseMInt = map (map read)


-- Counts the number of occurences of a given number
-- in the each question column
count :: Int -> [[Int]] -> [[Int]]
count f m = map (\c -> [c]) $ foldr op [] m
    where 
        op x [] = map (\c -> if c == f then 1 else 0) x
        op x y = zipWith (+) y (map (\c -> if c == f then 1 else 0) x)


-- Replaces the empty strings with "0"
-- and converts the strings to Int
compute :: Table -> [[Int]]
compute m = parseMInt.(map $
        map (\c -> if c == "" then "0" else c)) $ 
        cut m


-- Combines the arrays of occurences 
-- and converts the numbers into strings
op :: [[Int]] -> Table
op m = map (map show) $
        zipWith (++) a $ 
        (count 2) m
        where a = zipWith (++) ((count 0) m)  ((count 1) m)


get_exam_summary :: Table -> Table
get_exam_summary m = ["Q", "0", "1", "2"] : 
        (zipWith (:) ["Q1","Q2","Q3","Q4","Q5","Q6"] (op $ compute m))


-- Task 5

-- Sorts ascending by grade
byGrade :: [[String]] -> [[String]]
byGrade = sortBy cmp 
    where 
        aux :: String -> Float
        aux s = read s
        cmp :: [String] -> [String] -> Ordering
        cmp s1 s2 
            | (aux (s1 !! 1)) > (aux (s2 !! 1)) = GT
            | (aux (s1 !! 1)) == (aux (s2 !! 1)) = EQ
            | otherwise = LT


-- Sorts ascending by name on the column with index given as parameter
byName :: Int -> Table -> Table
byName x = sortBy cmp
    where 
        aux :: String -> Float
        aux s = read s
        cmp :: [String] -> [String] -> Ordering
        cmp s1 s2
            | (aux (s1 !! x)) == (aux (s2 !! x)) && (s1 !! 0) > (s2 !! 0) = GT
            | (aux (s1 !! x)) == (aux (s2 !! x)) && (s1 !! 0) == (s2 !! 0) = EQ
            | otherwise = LT


get_ranking :: Table -> Table
get_ranking m = ["Nume","Punctaj Exam"] : ((byName 1) $ 
        byGrade $ 
        zipWith op (drop 1 m) (map (map (printf "%.2f")) (addEx m (calculate m))))
    where 
        op r l = (head r) : l


-- Task 6

-- Sorts ascending by the difference of grades
byDiff :: [[String]] -> [[String]]
byDiff = sortBy cmp 
    where 
        aux :: String -> Float
        aux s = read s
        cmp :: [String] -> [String] -> Ordering
        cmp s1 s2 
            | (aux (s1 !! 3)) > (aux (s2 !! 3)) = GT
            | (aux (s1 !! 3)) == (aux (s2 !! 3)) = EQ
            | otherwise = LT


-- Calculates the total points from the 6 questions
op3 :: Table -> [[Float]]
op3 m = map (\c -> [c]) $
        map ((/4).(foldr (\x y -> x + y) 0)) $
        (parseM.(map (map (\c -> if c == "" then "0" else c)))) $ 
        cut m


-- Calculates the difference between Interview and Written Exam
diff :: [[Float]] -> [[Float]]
diff m = map ((\c -> [c]).aux1.aux2) m
    where 
        aux1 = \c -> if c < 0 then -c else c
        aux2 = \c -> ((c !! 0) - (c !! 1))


-- Concatenates the interview points the written exam grade
concatGrades :: Table -> [[Float]]
concatGrades m = zipWith (++) (op3 m) (map ((\c -> [c]).read.(!! 7)) (drop 1 m))


get_exam_diff_table :: Table -> Table
get_exam_diff_table m = ["Nume","Punctaj interviu","Punctaj scris","Diferenta"]:
        ((byName 3) $ 
        byDiff $ 
        zipWith (:) (map head (drop 1 m)) (map (map (printf "%.2f")) $ 
        zipWith (++) (concatGrades m) (diff $ 
        concatGrades m)))

{-
    TASK SET 2
-}


op32 :: Char -> Char -> [String] -> [String]
op32 c x [] 
        | x /= c = [[x]] 
        | c /= '\n' = []:[""]
        | otherwise = []
op32 c x (y:ys) = if x /= c then ([x]++y):ys
    else []:(y:ys)

-- Splits a string after the given character
mysplit :: Char -> String -> [String]
mysplit = \c l -> foldr (op32 c) [] l

-- Reads a string in csv form and returns a table
read_csv :: CSV -> [[String]]
read_csv l = (map (mysplit ',') (mysplit '\n' l))

op' :: Table -> Table
op' t = map (map (\c -> if c == "" then "-1" else c)) t

op'' :: Table -> Table
op'' t = map (map (\c -> if c == "" then "$" else c)) t

restore :: [String] -> [String]
restore l = map op l where 
    op [] = []
    op (x:xs) = if x == '$' then op xs else x:(op xs)

aux1 :: String -> String -> String
aux1 s1 [] = s1
aux1 s1 acc = s1 ++ "," ++ acc 

op2 :: [String] -> String
op2 l = foldr aux1 [] l

aux2 :: String -> String -> String
aux2 s1 [] = s1
aux2 "" acc = acc
aux2 s1 acc = s1 ++ "\n" ++ acc

op4 :: [String] -> String
op4 l = foldr aux2 [] l

-- Writes a table as a string in csv form
write_csv :: Table -> CSV
write_csv l = op4 $ restore (map op2 $ op'' l)


-- Task 1

op5 :: String -> [String] -> Int -> Int
op5 s l i 
        | (head l) == s = i 
        | otherwise = (op5 s (tail l) (i+1))

-- Finds the index of a column with the given name
find_col_index :: String -> Table -> Int
find_col_index s t = op5 s (head t) 0
        
-- Returns the values from the column as a list
as_list :: String -> Table -> [String]
as_list s t = foldr (op6 (find_col_index s t)) [] (tail t) where 
    op6 x l acc = (l!!x):acc


-- Task 2
-- Sorts the table by the given column (index)
byCol :: Int -> Table -> Table
byCol x t = if (((head t)!!x) == "Nume" || ((head t)!!x) == "Email") 
    then (head t):(sortBy cmp1 (tail $ op' t))
            else (head t):(sortBy cmp2 (tail $ op' t))
    where 
        aux :: String -> Float
        aux s = read s
        cmp2 :: [String] -> [String] -> Ordering
        cmp2 s1 s2 
            | (aux (s1 !! x)) > (aux (s2 !! x)) = GT
            | (aux (s1 !! x)) == (aux (s2 !! x)) = EQ
            | otherwise = LT
        cmp1 :: [String] -> [String] -> Ordering
        cmp1 s1 s2 
            | (s1 !! x) > (s2 !! x) = GT
            | (s1 !! x) == (s2 !! x) = EQ
            | otherwise = LT
        
-- Sorts by the first column
byFirst :: Int -> Table -> Table
byFirst x t = if (((head t)!!x) == "Nume" || ((head t)!!x) == "Email") 
    then (head t):(sortBy cmp1 (tail $ op' t))
            else (head t):(sortBy cmp2 (tail $ op' t))
    where 
        aux :: String -> Float
        aux s = read s
        cmp2 :: [String] -> [String] -> Ordering
        cmp2 s1 s2 
            | (aux (s1 !! x)) == (aux (s2 !! x)) && (s1 !! 0) > (s2 !! 0) = GT
            | (aux (s1 !! x)) == (aux (s2 !! x)) && (s1 !! 0) == (s2 !! 0) = EQ
            | otherwise = LT
        cmp1 :: [String] -> [String] -> Ordering
        cmp1 s1 s2 
            | (s1 !! x) == (s2 !! x) && (s1 !! 0) > (s2 !! 0) = GT
            | (s1 !! x) == (s2 !! x) && (s1 !! 0) == (s2 !! 0) = EQ
            | otherwise = LT

-- Sorts the table by the given column
tsort :: String -> Table -> Table
tsort s t = map (map (\c -> if c == "-1" then "" else c)) $ 
        byFirst (find_col_index s t) $ byCol (find_col_index s t) t


-- Task 3
-- Applies the given function to all the values
vmap :: (Value -> Value) -> Table -> Table
vmap f t = map (map f) t


-- Task 4
-- Applies the given function to all the entries
rmap :: (Row -> Row) -> [String] -> Table -> Table
rmap f h t = h : (map f (drop 1 t))

get_hw_grade_total :: Row -> Row
get_hw_grade_total r = (head r) : [(printf "%.2f") (op r)]
    where 
        op :: Row -> Float
        op r = (foldr (+) 0 (map read (extract $ map replace r)))
        extract r = drop 2 r
        replace = \c -> if c == "" then "0" else c


-- Task 5

equal_rows :: Row -> Row -> Bool
equal_rows [] [] = True
equal_rows [] r2 = False
equal_rows r1 [] = False
equal_rows r1 r2 = ((head r1) == (head r2)) && (equal_rows (tail r1) (tail r2))

-- Concat 2 tables vertically if their columns are the same
vunion :: Table -> Table -> Table
vunion t1 t2 = if (equal_rows (head t1) (head t2)) == True then 
    (t1 ++ (tail t2)) else t1


-- Task 6

empty_line :: Int -> Row -> Row
empty_line 0 acc = acc
empty_line x acc = empty_line (x-1) ("" : acc)

-- Concat 2 tables horrizontally
hunion :: Table -> Table -> Table
hunion t1 t2 = op (length (head t1)) (length (head t2)) t1 t2 
        where 
            op :: Int -> Int -> Table -> Table -> Table
            op l1 l2 [] [] = []
            op l1 l2 [] (y:ys) = ((empty_line l1 [])++y):(op l1 l2 [] ys)
            op l1 l2 (x:xs) [] = (x++(empty_line l2 [])):(op l1 l2 xs [])
            op l1 l2 (x:xs) (y:ys) = (x++y):(op l1 l2 xs ys)


-- Task 7

op5' :: String -> [String] -> Int -> Int
op5' s l i 
        | (head l) == s = i 
        | i < (length l) = (op5' s (tail l) (i+1))
        | otherwise = -1

find_col_index' :: String -> Table -> Int
find_col_index' s t = op5' s (head t) 0

merge_lines :: Int -> Int -> Row -> Row -> Row
merge_lines a b r1 r2 = r1 ++ ((take b r2) ++ (drop (b+1) r2))

find_entry :: Int -> String -> Table -> Row
find_entry i s [] = []
find_entry i s (x:xs) = if (x!!i) == s then x else find_entry i s xs

op10 :: Int -> Int -> Int -> Table -> Table -> Table
op10 l i1 i2 [] t2 = []
op10 l i1 i2 (x:xs) t2 
        | ((find_entry i2 (x!!i1) t2) /= []) = 
            aux:(op10 l i1 i2 xs t2)
        | otherwise = (x++(empty_line (l-1) [])):(op10 l i1 i2 xs t2)
        where 
            aux = (merge_lines i1 i2 x (find_entry i2 (x!!i1) t2))

create_table1 :: String -> Table -> Table -> Table
create_table1 s t1 t2 = op10 (length (head t2)) i1 i2 t1 t2
    where 
        i1 = (find_col_index' s t1)
        i2 = (find_col_index' s t2)

-- Merges 2 tables
tjoin :: String -> Table -> Table -> Table
tjoin s t1 t2 = create_table1 s t1 t2


-- Task 8

apply :: (Row -> Row -> Row) -> Row -> [Row] -> [Row]
apply f r1 r2 = map (f r1) r2

op7 :: (Row -> Row -> Row) -> Table -> Table -> Table
op7 f [] t2 = []
op7 f (x:xs) t2 = (map (f x) t2) ++ (op7 f xs t2)

-- Makes the cartesian product and applies the given function
cartesian :: (Row -> Row -> Row) -> [String] -> Table -> Table -> Table
cartesian f h t1 t2 = h : (op7 f (tail t1) (tail t2))


-- Task 9

op8 :: [String] -> [[String]]
op8 = (map (\c -> [c]))

op9 :: [String] -> Table -> Table
op9 [] t1 = []
op9 (x:[]) t1 = op8 (as_list x t1)
op9 (x:xs) t1 = zipWith (++) (op8 (as_list x t1)) (op9 xs t1)

-- Extracts the specified columns
projection :: [String] -> Table -> Table
projection s t = s : (op9 s t)


{-
    TASK SET 3
-}


-- Define FilterCondition a
data FilterCondition a =
    Eq String a |
    Lt String a |
    Gt String a |
    In String [a] |
    FNot (FilterCondition a) |
    FieldEq String String


-- Define FilterOp
type FilterOp = Row -> Bool


-- Define FEval class
class FEval a where
    feval :: [String] -> (FilterCondition a) -> FilterOp


-- Instance for (FEval Float)
instance FEval Float where
    feval colnames (Eq s val) row = 
        (read ((map op row) !! i) :: Float) == val
        where 
            i = op5 s colnames 0
            op c = if c == "" then "0" else c
    feval colnames (Lt s val) row = 
        (read ((map op row) !! i) :: Float) < val
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
    feval colnames (Gt s val) row = 
        (read ((map op row) !! i) :: Float) > val
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
    feval colnames (In s l) row = 
        is_in_list (read ((map op row) !! i) :: Float) l
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
            is_in_list a [] = False
            is_in_list a (x:xs) = if a == x then True else is_in_list a xs
    feval colnames (FNot f) row = not (feval colnames f row)
    feval colnames (FieldEq s1 s2) row = (row !! i1) == (row !! i2)
        where
            i1 = op5 s1 colnames 0
            i2 = op5 s2 colnames 0


-- Instance for (FEval String)
instance FEval String where
    feval colnames (Eq s val) row = ((map op row) !! i) == val
        where 
            i = op5 s colnames 0
            op c = if c == "" then "0" else c
    feval colnames (Lt s val) row = ((map op row) !! i) < val
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
    feval colnames (Gt s val) row = ((map op row) !! i) > val
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
    feval colnames (In s l) row = is_in_list ((map op row) !! i) l
        where 
            i = op5 s colnames 0
            op = \c -> if c == "" then "0" else c
            is_in_list a [] = False
            is_in_list a (x:xs) = if a == x then True else is_in_list a xs
    feval colnames (FNot f) row = not (feval colnames f row)
    feval colnames (FieldEq s1 s2) row = (row !! i1) == (row !! i2)
        where
            i1 = op5 s1 colnames 0
            i2 = op5 s2 colnames 0


-- Define Query
data Query =
    FromCSV CSV
    | ToCSV Query
    | AsList String Query
    | Sort String Query
    | ValueMap (Value -> Value) Query
    | RowMap (Row -> Row) [String] Query
    | VUnion Query Query
    | HUnion Query Query
    | TableJoin String Query Query
    | Cartesian (Row -> Row -> Row) [String] Query Query
    | Projection [String] Query
    | forall a. FEval a => Filter (FilterCondition a) Query
    | Graph EdgeOp Query
    

-- where EdgeOp is defined:
type EdgeOp = Row -> Row -> Maybe Value

-- Define QResult
data QResult = CSV CSV | Table Table | List [String]

-- Instance for (Show QResult)
instance Show QResult where
    show (Table t) = write_csv t
    show (CSV c) = show c
    show (List l) = show l

-- Class Eval
class Eval a where
    eval :: a -> QResult
 

-- Enroll Query in class Eval
instance Eval Query where
    eval (FromCSV str) = (Table (read_csv str))
    eval (ToCSV query) = (CSV (show (eval query)))
    eval (AsList colname query) = 
        (List (as_list colname (read_csv $ show $ eval query)))
    eval (Sort colname query) = 
        (Table (tsort colname (read_csv $ show $ eval query)))
    eval (ValueMap op query) = 
        (Table (vmap op (read_csv $ show $ eval query)))
    eval (RowMap op colnames query) = 
        (Table (rmap op colnames (read_csv $ show $ eval query)))
    eval (VUnion query1 query2) = (Table (vunion (read_csv 
        $ show $ eval query1) (read_csv $ 
        show $ eval query2)))
    eval (HUnion query1 query2) = (Table (hunion (read_csv 
        $ show $ eval query1) (read_csv $ 
        show $ eval query2)))
    eval (TableJoin colname query1 query2) = 
        (Table (tjoin colname (read_csv 
            $ show $ eval query1) (read_csv 
            $ show $ eval query2)))
    eval (Cartesian op colnames query1 query2) = 
        (Table (cartesian op colnames (read_csv 
            $ show $ eval query1) (read_csv 
            $ show $ eval query2)))
    eval (Projection colnames query) = (Table (projection colnames (read_csv 
        $ show $ eval query)))
    eval (Filter f query) = 
        (Table ((head t) : (foldr (op (head t) f) [] (tail t))))
            where 
                op colnames f row acc = if (feval colnames f row) == True 
                    then row:acc else acc
                t = (read_csv $ show $ eval query)
    eval (Graph op query) = (Table (["From","To","Value"]:
                            (foldl (aux (tail t) op) [] (tail t))))
            where
                from_maybe (Just v) = v
                t = (read_csv $ show $ eval query)
                is_in_table v [] = False
                is_in_table v (x:xs) = if v == x then True 
                    else is_in_table v xs
                aux2 l op r1 r2 acc' 
                    | a /= Nothing = 
                        if (head r1) < (head r2) 
                            then (if (is_in_table v1 l) == False then v1:acc' 
                                else acc') 
                        else (if (((is_in_table v2 l) == False) && (r1 /= r2)) 
                            then v2:acc' 
                                else acc')
                    | otherwise = acc'
                    where 
                        a = (op r1 r2)
                        v1 = [(head r1), (head r2), (from_maybe a)]
                        v2 = [(head r2), (head r1), (from_maybe a)]
                aux l op acc r = acc++(foldr (aux2 acc op r) [] l)


-- EdgeOp for number of question with the same points
edge_op3 r1 r2 
            | (nr >= 5) = (Just (show nr))
            | otherwise = Nothing
        where
            aux [] [] acc = acc
            aux (x:xs) (y:ys) acc = if x == y then (aux xs ys (acc+1)) 
                else (aux xs ys acc)
            nr = (aux (tail r1) (tail r2) 0)


-- Similarities query
similarities_query = (Sort "Value" (Graph edge_op3 (Filter 
    (FNot $ (Eq "Email" "0")) $ FromCSV lecture_grades_csv)))


{-
    TASK SET 4
-}


-- Task 1


-- Extract the colon n from table t
extract_col n t = projection [n] t


-- Check if a line is in the table after the first element
found_in_table l [] = False
found_in_table l (x:xs) = if l!!0 == x!!0 then True else found_in_table l xs


-- Filter the entries from the given table that has not a match in the other
filter_unmatch [] t2 = []
filter_unmatch (x:xs) t2 = if ((found_in_table x t2) == False) 
    then x:(filter_unmatch xs t2)
    else filter_unmatch xs t2


-- Create the columns with the unmatched entries
generate colname t1 t2 = filter_unmatch col1 col2
    where 
        col1 = extract_col colname t1
        col2 = extract_col colname t2 


-- Calculate the distance between two strings
string_dist s1 s2 = op l1 l2
  where 
    l1 = length s1 
    l2 = length s2
    aux1 = listArray (1, l1) s1
    aux2 = listArray (1, l2) s2
    b = ((0, 0), (l1, l2))
    op' = listArray b l
        where
            aux (i1,i2) acc = (op i1 i2):acc
            l = foldr aux [] (range b)
    op i1 0 = i1
    op 0 i2 = i2
    op i1 i2
        | (aux1!i1) == (aux2!i2) = op'!(i1-1, i2-1)
        | otherwise =
            1 + minimum [ op'!(i1-1, i2), op'!(i1, i2-1), op'!(i1-1, i2-1)]
    

-- Find the entry in the table which is the closest for the given entry n
min_dist n [] mini acc = acc
min_dist n (x:xs) mini acc = if (dist <= mini) then min_dist n xs dist x 
        else min_dist n xs mini acc
    where
        dist = (string_dist (n!!0) (x!!0))


-- Get the match with minimum distance for each line in the first table
compute_dist [] t2 = []
compute_dist (x:xs) t2 = (min_dist x t2 (length (x!!0)) []):(compute_dist xs t2)


-- Merge the given columns
merge_cols colname t1 t2 = unite col1 col3
    where 
        col1 = (generate colname t1 t2)
        col2 = (generate colname t2 t1)
        col3 = (compute_dist col1 col2)
        unite l1 l2 = zipWith (++) l1 l2


-- Replace the typos for the given column
replace_typos :: String -> Table -> Table -> Table
replace_typos colname t1 t2 = op t1 ref
    where 
        index = find_col_index colname t1
        ref = merge_cols colname t1 t2
        aux [] x y = []
        aux (a:b) x y = if a == x then y:(aux b x y) else a:(aux b x y)
        repl [] l = l
        repl (x:xs) l = if ((l !! index) == (x !! 0)) 
            then (aux l (x!!0) (x!!1)) else repl xs l
        op t ref = map (repl ref) t


-- Correct the given table for the given column
correct_table :: String -> CSV -> CSV -> CSV
correct_table colname t1 t2 = write_csv $
    replace_typos colname (read_csv t1) (read_csv t2)


-- Task 2


-- Calculates the homework grade
calc_hw m = zipWith (++) (projection ["Nume"] m) (["Punctaj Teme"]:
    (map ((\c -> [c]).(printf "%.2f"))
     (map (foldr (+) 0) ((parseM.(map (map replace))) $ 
        extract m))))
    where 
        extract m = map (\r -> (drop 1 r)) $ drop 1 m
        replace = \c -> if c == "" then "0" else c

op_aux r = if (r !! 0) == "" then False else True


-- Calculates the lecture grade
calc_lect m = zipWith (++) (projection ["Email"] filtered) (["Punctaj Curs"]:
    (map ((\c -> [c]).(printf "%.2f").(/no).(*2))
     (map (foldr (+) 0) ((parseM.(map (map replace))) $ 
        extract filtered))))
    where 
        extract m = map (\r -> (drop 1 r)) $ drop 1 m
        replace = \c -> if c == "" then "0" else c
        no = fromIntegral ((length $ head filtered)-1) :: Float
        filtered = filter op_aux m


-- Gets the correct the email map
right_map map = read_csv $ correct_table "Nume" map hw_grades_csv


-- Replaces email with the corresponding name
replace_email1 [] map = []
replace_email1 (x:xs) map = (op x map):(replace_email1 xs map)
    where 
        op l [] = l
        op l (x:xs) = if (l!!0) == (x!!1) then (x!!0):[l!!1]
            else op l xs


-- Change the header for the lecture table
replace_email2 t1 map = ["Nume", "Punctaj Curs"]:(drop 1 t2)
    where
        t2 = replace_email1 t1 map


-- Merges three tables
merge_tables hw lect exam = tjoin "Nume" (tjoin "Nume" hw lect) exam


-- Add the total points column to the given row
add_total_row :: [String] -> [String]
add_total_row r = r ++ [calc_total (hw_grade r) (lect_grade r) (exam_grade r)]
    where 
        hw_grade :: [String] -> Float
        hw_grade r = read (r!!1)
        lect_grade :: [String] -> Float
        lect_grade r = read (r!!2)
        exam_grade :: [String] -> Float
        exam_grade r = read (r!!3)
        calc_total h l e 
            | h + l < 2.5 || e < 2.5 = "4.00"
            | otherwise = (printf "%.2f") $ ((minimum [h + l, 5]) + e)


-- Sorts by name the table
byName' :: Table -> Table
byName' = sortBy cmp
    where 
        cmp :: [String] -> [String] -> Ordering
        cmp s1 s2
            | (s1 !! 0) > (s2 !! 0) = GT
            | (s1 !! 0) == (s2 !! 0) = EQ
            | otherwise = LT


-- Compute the centralised table
grades :: CSV -> CSV -> CSV -> CSV -> CSV
grades email_map hw exam lect =  write_csv $
    ["Nume", "Punctaj Teme", "Punctaj Curs", "Punctaj Exam", "Punctaj Total"]:m
    where 
        op t = (map add_total_row (drop 1 t))
        t1 = calc_hw (read_csv hw)
        t2 = replace_email2 (calc_lect (read_csv lect)) (right_map email_map)
        t3 = compute_exam_grades $ read_csv exam  
        t = merge_tables t1 t2 t3
        m = (byName' $ 
            map (map (\c -> if c == "0" then "" else c)) $ 
            op $ map (map (\c -> if c == "" then "0" else c)) $ t)
    